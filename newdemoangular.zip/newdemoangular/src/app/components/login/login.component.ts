import { Component } from '@angular/core';
import { FormGroup,FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginServiceService } from 'src/app/services/login-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {

    regForm!: FormGroup;
  
    constructor(private fb: FormBuilder,private loginService:LoginServiceService,private router:Router) {}
  
    ngOnInit() {
      this.regForm = this.fb.group({
        userName: ['',[Validators.required]],
        pwd: ['',[Validators.required]],
      });
    }
  
    login() {
      if(this.regForm.valid){
      let obj = {
         username: this.regForm.get('userName')?.value,
         password: this.regForm.get('pwd')?.value,
      };

      console.log('userData', obj);
      this.loginService.login(obj).subscribe((res:any)=>{
        console.log(res);
        if(res){
          localStorage.setItem('username',obj.username);
          localStorage.setItem('token',res.token);
        this.router.navigateByUrl('/dashboard');
        }
        else {
          console.log("please enter correct Username & Password");
        }
      })
      }
      else {
        this.regForm.markAllAsTouched();
      }
  
      
    }
    register(){
      let regObj = {
         username: this.regForm.get('userName')?.value,
         password: this.regForm.get('pwd')?.value,
      }
      this.loginService.register(regObj).subscribe((res:any)=>{
        console.log(res);
        if(res){
        alert ('Registration done.you need to login first');
        }
        else {
          console.log("please enter correct Username & Password");
        }
      })

    }

    reset(){
      this.regForm.reset();
    }

}
