import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-user-dialog',
  templateUrl: './user-dialog.component.html',
  styleUrls: ['./user-dialog.component.scss']
})
export class UserDialogComponent {

  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<UserDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.form = this.fb.group({
      id: [data && data.id ? Number(data.id) : null, Validators.required],
      orderid: [data && data.orderid ? Number(data.orderid) : null, Validators.required],
      productids: [data && data.productids ? data.productids : [], Validators.required],
      productname: [data && data.productname ? data.productname : '', Validators.required],
      totalamount: [data && data.totalamount ? Number(data.totalamount) : null, Validators.required]
    });


  }

  save() {
    this.dialogRef.close(this.form.value);
  }

  cancel() {
    this.dialogRef.close();
  }

}
