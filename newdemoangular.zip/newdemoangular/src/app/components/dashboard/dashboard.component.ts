import { Component } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { LoginServiceService } from 'src/app/services/login-service.service';
import { OrderService } from 'src/app/services/order.service';
import { UserDialogComponent } from '../user-dialog/user-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
export interface User {
  id: number;
  name: string;
  email: string;
  isEdit?: boolean;    // flag to toggle edit mode
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent {
  displayedColumns: string[] = ['orderid', 'id', 'productId', 'productname', 'totalAmount', 'actions'];
  //dataSource = new MatTableDataSource<User>();
  userData: any;
  dataSource: any[] = [];
  constructor(private orderService: OrderService, private snackBar:MatSnackBar, private router: Router, private dialog: MatDialog) {

  }
  ngOnInit() {
    this.userData = localStorage.getItem('username');
    this.getData();
  }

  getData() {
    this.orderService.orderData().subscribe((res: any) => {
      console.log("data", res)
      this.dataSource = res.data;
    });
  }

  addUser() {
    const dialogRef = this.dialog.open(UserDialogComponent, {
      width: '50%',
      data: null
    });

    dialogRef.afterClosed().subscribe((result: any) => {

      console.log("res::", result);


      if (result) {
        const payload = {
          id: Number(result.id),
          productIds: Number(result.productids),
          productname: result.productname,
          totalAmount: Number(result.totalamount)
        };
        this.orderService.addData(payload).subscribe((res: any) => {
          console.log(res);
           this.snackBar.open('Order is Added', 'Close', {
           duration: 1500   
          });
          this.getData();
        });
      }
    });
  }

  editUser(user: User) {
    const dialogRef = this.dialog.open(UserDialogComponent, {
      width: '50%',
      data: user
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      console.log("result", result);
      if (result) {
        const payload = {
          id: Number(result.id),
          orderid: Number(result.orderid),
          productIds: Number(result.productids),
          productname: result.productname,
          totalAmount: Number(result.totalamount)
        };
        this.orderService.editData(payload.orderid, payload).subscribe((res: any) => {
          console.log(res);
           this.snackBar.open('Order is Updated', 'Close', {
            duration: 1500   
          });
          this.getData();
        });
      }
    });
  }

  delete(orderId: any) {
    if (isNaN(orderId)) {
      console.error("Row orderId is not a number!", orderId);
      return;
    }
    this.orderService.deleteData(orderId).subscribe((res: any) => {
      console.log(res.message);
      this.snackBar.open('Order is deleted', 'Close', {
      duration: 1500   
      });
      this.getData();
    });
  }

  logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    localStorage.clear();
    this.router.navigateByUrl('/login');
  }
}



