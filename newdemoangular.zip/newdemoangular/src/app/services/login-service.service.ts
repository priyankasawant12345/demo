import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginServiceService { 
   private http = inject(HttpClient);
  
  login(userData:any){
    return this.http.post('http://localhost:3000/login',userData)
  }
   register(userData:any){
    return this.http.post('http://localhost:3000/register',userData)
  }

 
}
