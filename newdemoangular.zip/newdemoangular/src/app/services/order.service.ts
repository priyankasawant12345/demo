import { HttpClient } from '@angular/common/http';
import { inject,Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

private http = inject(HttpClient);

  orderData(){
    return this.http.get('http://localhost:3000/orders');
  }
  addData(orderData:any){
    return this.http.post('http://localhost:3000/api/orders',orderData);
  }
  editData(orderId:number,orderData: any): Observable<any>{
     return this.http.put(`http://localhost:3000/orders/update/${orderId}`,orderData, { headers: { 'Content-Type': 'application/json' } });
  }
  deleteData(orderId:number): Observable<any>{
    return this.http.delete(`http://localhost:3000/orders/delete/${orderId}`);
  }
}
