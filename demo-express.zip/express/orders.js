const express = require("express");
const router = express.Router();
const cors = require('cors');
const db = require('./db');
const oracledb = require("oracledb");
router.use(express.json());
router.use(cors());


// GET all orders
router.get('/orders', async (req, res) => {
  let connection;

  try {
    // Disable caching
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.set('Pragma', 'no-cache');
    res.set('Expires', '0');
    res.set('Surrogate-Control', 'no-store');

    connection = await db.getConnection();
    const result = await connection.execute(
      `SELECT orderid, id, productids, totalamount, productname 
       FROM system.orders ORDER BY orderid`,
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );
    // await connection.close();

    const mappedRows = result.rows.map(row => ({
      orderid: row.ORDERID,
      id: row.ID,
      productids: row.PRODUCTIDS,
      totalamount: row.TOTALAMOUNT,
      productname: row.PRODUCTNAME
    }));

    res.json({
      success: true,
      data: mappedRows 
    });

  } catch (err) {
    console.error("DB Error:", err);
    res.status(500).json({ success: false, error: err.message });

  }
  finally {
    if (connection) await connection.close();
  }

});


// =========================
// CREATE ORDER
// =========================
router.post("/api/orders", async (req, res) => {
  const { id, productIds, totalAmount, productname } = req.body;

  const idNum = parseInt(id);
  const totalAmountNum = parseFloat(totalAmount);

  if (isNaN(idNum) || isNaN(totalAmountNum)) {
    return res.status(400).json({ error: "id and totalAmount must be valid numbers" });
  }

  let connection;

  try {
    connection = await db.getConnection();
    const result = await connection.execute(
      `INSERT INTO system.orders (orderId,id, productIds, totalAmount,productname) 
       VALUES (orders_seq.NEXTVAL,:id, :productIds, :totalAmount,:productname)
       RETURNING orderId INTO :orderId`,
      {

        id: idNum,
        productIds,
        totalAmount: totalAmountNum,
        productname,
        orderId: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
      },
      { autoCommit: true }
    );

    await connection.close();
    res.json({ message: "Order created", orderId: result.lastRowid });

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error creating order" });
  }
});



// =========================
// UPDATE ORDER
// =========================
router.put("/orders/update/:orderId", async (req, res) => {
  const { orderId } = req.params;
  const { id, productIds, totalAmount, productname } = req.body;

  const idNum = parseInt(id);
  const totalAmountNum = parseFloat(totalAmount);

  if (isNaN(idNum) || isNaN(totalAmountNum)) {
    return res.status(400).json({ error: "id and totalAmount must be valid numbers" });
  }

  let connection;

  try {
    connection = await db.getConnection();
    const result = await connection.execute(
      `UPDATE orders 
       SET id = :id, productIds = :productIds, totalAmount = :totalAmount, productname =:productname
       WHERE orderId = :orderId`,

      {
        id: idNum,
        productIds,
        totalAmount: totalAmountNum,
        productname,
        orderId
      },
      { autoCommit: true } 
    );

    await connection.close();

    if (result.rowsAffected === 0) {
      return res.status(404).json({ error: "Order not found" });
    }

    res.json({ message: "Order updated successfully" });

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error updating order" });
  }
});

// =========================
// DELETE ORDER
// =========================
router.delete("/orders/delete/:orderId", async (req, res) => {

  const orderId = Number(req.params.orderId);
  // Validate number
  if (isNaN(orderId)) {
    return res.status(400).json({ error: "Invalid orderId (must be a number)" });
  }
  console.log("Incoming orderIddd:", req.params.orderId);
  let connection;
  try {
    connection = await db.getConnection();
    const result = await connection.execute(
      `DELETE FROM system.orders WHERE orderId = :orderId`,
      { orderId },
      { autoCommit: true }
    );

    await connection.close();

    if (result.rowsAffected === 0) {
      return res.status(404).json({ error: "Order not found" });
    }

    res.json({ message: "Order deleted successfully" });

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error deleting order" });
  }
});

module.exports = router;
