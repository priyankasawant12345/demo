const oracledb = require("oracledb");
const express = require('express');
const bcrypt = require('bcrypt');
const cors = require('cors');
const db = require('./db');
const jwt = require("jsonwebtoken");
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";


const app = express();
app.use(express.json());
app.use(cors());


const orderRoutes = require("./orders");//("./routes/order");
app.use("/", orderRoutes);

(async function init() {
  await db.initialize();
})();




app.get('/', (req, res) => {
  res.send('Hello World!');
});
// ========================
// USER REGISTRATION
// ========================
app.post('/register', async (req, res) => {
  const { username, password } = req.body;

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const connection = await db.getConnection();

    const result = await connection.execute(
      `INSERT INTO users (username, password) VALUES (:username, :password)`,
      { username, password: hashedPassword },
      { autoCommit: true }
    );

    await connection.close();
    res.json({ message: "User registered successfully" });

  } catch (error) {
    console.error(error);
    if (error.errorNum === 1) { // unique constraint violation
      return res.status(400).json({ error: "Username already exists" });
    }
    res.status(500).json({ error: "Registration failed" });
  }
});

// ========================
// USER LOGIN
// ========================
app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const connection = await db.getConnection();
    const result = await connection.execute(
      `SELECT * FROM system.users WHERE username = :username`,
      { username },
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );

    await connection.close();

    if (result.rows.length === 0) {
      return res.status(400).json({ error: "Invalid username or password" });
    }

    const user = result.rows[0];
    const valid = await bcrypt.compare(password, user.PASSWORD);

    if (!valid) {
      return res.status(400).json({ error: "Invalid username or password" });
    }

    // 👉 Generate JWT token
    const token = jwt.sign(
      { userId: user.ID, username: user.USERNAME },
      JWT_SECRET,
      { expiresIn: "1h" }
    );


    res.json({ message: "Login successful", userId: user.ID,token });

  } catch (error) {
    console.error("Login error",error);
    res.status(500).json({ error: "Login failed" });
  }
});

// ========================
// START SERVER
// ========================
app.listen(3000, () => {
  console.log("Server running on port 3000");
});
