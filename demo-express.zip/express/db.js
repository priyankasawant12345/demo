const oracledb = require('oracledb');

const dbConfig = {
  user: 'system',
  password: 'manager',
  connectString: "Priyanka:1521/orclpdb"
  //connectString: 'localhost:1521/ORCLCDB.XEPDB1' // adjustPDB$SEED for your DB  orclpdb
};

    console.log("✅ Oracle DB connected successfully");


async function initialize() {
  await oracledb.createPool(dbConfig);
  console.log("Oracle DB pool created");
}
async function getConnection() {
  return oracledb.getConnection();
}

module.exports = { initialize, getConnection };